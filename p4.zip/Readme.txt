How to Run pow-create:

./pow-create #bits samplefile 

How to run pow-check:

./pow-check sampleheader samplefile