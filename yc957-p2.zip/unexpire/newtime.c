#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <dlfcn.h>

// Name:Yinfeng Cong
// netID:yc957
// RUID:186005832
// your code for time() goes here
int test = 0;

time_t time(time_t *tim){
    if( test == 0 ){
        struct tm tm;
        memset(&tm, 0, sizeof(struct tm));
        if(tim == NULL){
            tim = (time_t*) malloc(sizeof(time_t));
        }

        if( strptime("2021-11-11 8:00:00", "%Y-%m-%d %H:%M:%S", &tm) == NULL ){
            printf("error setting struct\n");
            return 0;
        }
        
        *tim = mktime(&tm);
        test = 1;
        return *tim;
    }
    
    time_t (*fuc) (time_t* tim);
    fuc = dlsym(RTLD_NEXT, "time");

    return fuc(tim);

}

int main(){
	if (test == 1 ){
		//return false;
		}
	if (test == 0){
		
	}
	else if (test != 1 & test != 0){
		return 0;
	}
}