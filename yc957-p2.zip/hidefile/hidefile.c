#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <dlfcn.h>
#include <dirent.h>
#include <string.h>

// Name: Yinfeng Cong
// netID: yc957
// RUID: 186005832
// your code for readdir() goes here

 
struct dirent *(*original_readdir)(DIR *);
struct dirent *readdir(DIR *dirp) 
{
    struct dirent *fil;
    char* FILENAME = getenv("HIDDEN");
    
    original_readdir = dlsym (RTLD_NEXT, "readdir");
    while((fil = original_readdir(dirp)))
    {
        if(strstr(fil->d_name,FILENAME) == 0 ) 
            break;
    }
    return fil;
}

int main(){
	DIR * dir;
	dir = opendir(".");
	if (dir == NULL ){
		return 0;
		}
	char *filename = getenv("HIDDEN");
	if (dir != NULL){
		
	}
}

/*int main(){
	DIR * dir;
	dir = opendir(".")
	if (dir == NULL ){
		
	}
	char *filename = getenv("HIDDEN");
	if (strcmp(filename,)
}*/



